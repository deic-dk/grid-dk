# Example script for starting MVD from a Python script.
import os
import MvdWrapper

# First we will create an output dir
outputPath = 'outputData'
complex = '1hvr'

if (not os.path.exists( outputPath )):
	os.mkdir( outputPath )
	
if os.path.exists( outputPath ) and os.path.isdir( outputPath ):
	print 'Created outputPath: ' + outputPath
else:
	raise IOError, 'could not create path' + outputPath

# Now start the wrapper...
# Remember to change the path to the executable to the actual installation of MVD.
#
# Notice that on Windows you will need to point the wrapper to the MVDConsole.exe executable, not the MVD.exe!
# Also be careful with backslashes in filenames, since they work as escape characters in Python.
# The 'gui' flag determines whether to launch the GUI or not.
#
# Also notice that the communication is asynchronous, that is the MvdWrapper will just send commands to a command queue in MVD, not waiting for them to finish.
# If you need to synchronize with other programs, you can insert a 'mvd.waitUntilReady()' command, which will force Python to wait until all commands in the command queue has been processed.
mvd = MvdWrapper.MvdWrapper("C:/Program Files/Molegro/MVD2007/bin/mvdconsole.exe", gui=True)
mvd.info("testing")
mvd.random(123232)                    	# set the seed (normally you would not set this!)
mvd.cd(outputPath)			# change to output path
mvd.download(complex, complex + ".pdb") # download from pdb.org
mvd.importFrom("All", complex + ".pdb")	# import into workspace
mvd.rmsd("ligand[0]")		# set a ligand as a rmsd reference
mvd.dock("")			# start the docking
mvd.exit()
