import os
import subprocess
import errno
import time
import sys
import select

# The first part of the file simply deals with spawning and communicating with processes through pipes in a generic way.
# Look below for the actual MvdWrapper class.
if subprocess.mswindows:
    from win32file import ReadFile, WriteFile
    from win32pipe import PeekNamedPipe
    import msvcrt

class Popen(subprocess.Popen):
    def __init__(self, *args, **kwargs):
        subprocess.Popen.__init__(self, *args, **kwargs)
        self._setup()
    
    def recv(self, maxsize=None):
        return self._recv('stdout', maxsize)
    
    def recv_err(self, maxsize=None):
        return self._recv('stderr', maxsize)

    def send_recv(self, input='', maxsize=None):
        return self.send(input), self.recv(maxsize), self.recv_err(maxsize)

    def get_conn_maxsize(self, which, maxsize):
        if maxsize is None:
            maxsize = 1024
        elif maxsize < 1:
            maxsize = 1
        return getattr(self, which), maxsize
    
    def _close(self, which):
        getattr(self, which).close()
        setattr(self, which, None)
    
    if subprocess.mswindows:
        def _setup(self):
            pass
        
        def send(self, input):
            if not self.stdin:
                return None

            try:
                x = msvcrt.get_osfhandle(self.stdin.fileno())
                (errCode, written) = WriteFile(x, input)
            except ValueError:
                return self._close('stdin')
            except (subprocess.pywintypes.error, Exception), why:
                if why[0] in (109, errno.ESHUTDOWN):
                    return self._close('stdin')
                raise

            return written

        def _recv(self, which, maxsize):
            conn, maxsize = self.get_conn_maxsize(which, maxsize)
            if conn is None:
                return None
            
            try:
			x = msvcrt.get_osfhandle(conn.fileno())
			(read, nAvail, nMessage) = PeekNamedPipe(x, 0)
			if maxsize < nAvail:
				nAvail = maxsize
			if nAvail > 0:
				(errCode, read) = ReadFile(x, nAvail, None)
            except ValueError:
                return self._close(which)
            except (subprocess.pywintypes.error, Exception), why:
                if why[0] in (109, errno.ESHUTDOWN):
                    return self._close(which)
                raise
            
            if self.universal_newlines:
                read = self._translate_newlines(read)
            return read

    else:
        def _setup(self):
            import fcntl
            for i in (self.stdin, self.stdout, self.stderr):
                flags = fcntl.fcntl(i, fcntl.F_GETFL)
                fcntl.fcntl(i, fcntl.F_SETFL, flags | os.O_NONBLOCK)
        
        def send(self, input):
            if not self.stdin:
                return None

            if not select.select([], [self.stdin], [], 0)[1]:
                return 0

            try:
                written = os.write(self.stdin.fileno(), input)
            except OSError, why:
                if why[0] == errno.EPIPE: #broken pipe
                    self.stdin.close()
                    self.stdin = None
                    return None
                raise

            return written

        def _recv(self, which, maxsize):
            conn, maxsize = self.get_conn_maxsize(which, maxsize)
            if conn is None:
                return None
            
            if not select.select([conn], [], [], 0)[0]:
                return ''
            
            r = conn.read(maxsize)
            if not r:
                conn.close()
                setattr(self, which, None)
                return None

            if self.universal_newlines:
                r = self._translate_newlines(r)
            return r

message = "Other end disconnected!"

def recv_some(p, t=.1, e=1):
    x = time.time()+t
    y = []
    r = ''
    while time.time() < x or r:
        r = p.recv()
        if r is None:
            if e:
                raise Exception(message)
            else:
                break
        elif r:
            y.append(r)
        else:
            s = (x-time.time())/5
            if s > 0.0:
             time.sleep(s)
    return ''.join(y)
    
def send_all(p, data):
    while len(data):
        sent = p.send(data)
        if sent is None:
            raise Exception(message)
        data = buffer(data, sent)


        
        
# MvdWrapper ------------------------------------------------------------------------------------------------------------------------------------------------
#
# A simple example wrapper for spawning Molegro Virtual Docker from Python and wrapping often used commands.
class MvdWrapper:
	# -------------- Process initialization and communication -----------------------------

	# Constructor
	def __init__(self, executablePath, **extraArgs):
		self.executablePath = executablePath
		args = [self.executablePath,"-interactive"]
		if (extraArgs['gui'] == True) :
			print "Starting with GUI"
		if (extraArgs['gui'] == False) :
			print "Starting without GUI"
			args = [self.executablePath,"-interactive", "-nogui"]
		self.PIPE = subprocess.PIPE
		print self.executablePath
		self.process = Popen(args, stdin=self.PIPE, stdout=self.PIPE, stderr=self.PIPE)
		self.tail = "\r\n"
		
	# Send data through the pipe to MVD
	def writeLine(self, string):
		print "WriteLine: " + string
		send_all(self.process, string + self.tail)

	# Read data from the pipe
	def readLine(self):
		returnString = recv_some(self.process)
		return "ReadLine: " + returnString


		
	# Waits for the MVD process to have completed all pending commands.
	def waitUntilReady(self):
		# we will ask MVD to write a simple info message, and await for the acknowledgement that it has been processed.
		self.writeLine("info waitUntilReady")
		x = 0
		while x == 0:
			s = self.readLine()
			#print s
			if (s.find("waitUntilReady") > -1) :
				x=1
			else:
				time.sleep(0.1) # sleep for 0.1 seconds before asking again
		print "waitUntilReady completed."
		
	# Waits for the MVD process to terminate
	# Notice: be careful since MVD will not terminate until it has proccesed an 'exit' command.
	def waitForClose(self):
		self.process.wait()	

	# ------------ The wrapped commands. ------------------------------------------------------
		
	def importFrom(self, targets, file):
		self.writeLine("IMPORT " + targets + " FROM " + file)

	def optimizer(self, initstring):
		self.writeLine("OPTIMIZER " + initstring)

	def evaluator(self, initstring):
		self.writeLine("EVALUATOR " + initstring)
		
	def optimizertype(self, initstring):
		self.writeLine("OPTIMIZERTYPE " + initstring)

	def evaluatortype(self, initstring):
		self.writeLine("EVALUATORTYPE " + initstring)		

	def docksettings(self, initstring):
		self.writeLine("DOCKSETTINGS " + initstring)
		
	def prepare(self, initstring):
		self.writeLine("PREPARE " + initstring)
		
	def load(self, filename):
		self.writeLine("LOAD " + filename)
	
	def dock(self, ligandTargets):
		self.writeLine("DOCK " + ligandTargets)
	
	def download(self, PDBKey, filename):
		self.writeLine("DOWNLOAD " + PDBKey + " AS " + filename)

	def save(self, filename):
		self.writeLine("SAVE " + filename)
	
	def info(self, infostring):
		self.writeLine("INFO " + infostring)
	
	def cd(self, path):
		self.writeLine("CD " + path)
	
	def random(self, seed):
		self.writeLine("RANDOM " + str(seed))
	
	def new(self):
		self.writeLine("NEW")
		
	def rmsd(self, targetLigand):
		self.writeLine("RMSD " + targetLigand)

	def constraints(self, idlist):
		self.writeLine("Constraints " + idlist)
	
	def exit(self):
		self.writeLine("exit")

		